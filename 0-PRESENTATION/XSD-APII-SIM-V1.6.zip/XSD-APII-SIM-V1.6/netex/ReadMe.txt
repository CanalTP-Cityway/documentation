Schéma simplifié de la version 0.99.3 WIP4 de Netex.

NeTEX XMl schema
(C) 2009-2012  NeTEX , CEN, Crown Copyright
